cp -r .cache/chaoqi/anthropic_dpo_reverse_kl_pythia28_hh_2023-06-26_18-04-28_025916/ /net/scratch/RLHF/HH/pythia28/dpo_reverse_kl_pythia28_beta0.1/
cp -r .cache/chaoqi/anthropic_dpo_reverse_kl_pythia28_hh0.3_2023-06-28_15-30-35_463202/ /net/scratch/RLHF/HH/pythia28/dpo_reverse_kl_pythia28_beta0.3/
cp -r .cache/chaoqi/anthropic_dpo_reverse_kl_pythia28_hh0.9_2023-06-28_18-53-40_769782/ /net/scratch/RLHF/HH/pythia28/dpo_reverse_kl_pythia28_beta0.9/


cp -r .cache/chaoqi/anthropic_dpo_forward_kl_pythia28_hh_2023-06-26_18-07-32_466105/ /net/scratch/RLHF/HH/pythia28/dpo_forward_kl_pythia28_beta0.1/
cp -r .cache/chaoqi/anthropic_dpo_forward_kl_pythia28_hh0.3_2023-06-28_02-47-56_324382/ /net/scratch/RLHF/HH/pythia28/dpo_forward_kl_pythia28_beta0.3/
cp -r .cache/chaoqi/anthropic_dpo_forward_kl_pythia28_hh0.9_2023-06-28_11-30-25_720258/ /net/scratch/RLHF/HH/pythia28/dpo_forward_kl_pythia28_beta0.9/

cp -r .cache/chaoqi/anthropic_dpo_jsd_pythia28_hh_beta0.1_2023-06-26_22-55-06_694736/ /net/scratch/RLHF/HH/pythia28/dpo_jsd_pythia28_beta0.1/
cp -r .cache/chaoqi/anthropic_dpo_jsd_pythia28_hh_beta0.3_2023-06-27_23-31-57_221056/ /net/scratch/RLHF/HH/pythia28/dpo_jsd_pythia28_beta0.3/
cp -r .cache/chaoqi/anthropic_dpo_jsd_pythia28_hh_beta0.9_2023-06-27_20-07-26_575373/ /net/scratch/RLHF/HH/pythia28/dpo_jsd_pythia28_beta0.9/

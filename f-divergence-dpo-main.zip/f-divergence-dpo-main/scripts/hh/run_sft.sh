# 12:57pm, June 26, 2023
######## repeat training using sft on hh only
ulimit -n 64000; python -u train.py model=pythia28 datasets=[shp] loss=sft exp_name=shp_dpo_pythia28 gradient_accumulation_steps=4 batch_size=32 eval_batch_size=16 trainer=FSDPTrainer sample_during_eval=false model.fsdp_policy_mp=bfloat16
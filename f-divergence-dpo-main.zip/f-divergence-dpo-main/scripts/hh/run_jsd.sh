# 12:57pm, June 26, 2023
######## training for dpo using jsd but sft is done on hh and shp. #######
ulimit -n 64000; python -u train.py model=pythia28 datasets=[hh] loss=dpo fsdp_port=12355 loss.divergence=jsd loss.beta=0.3 loss.alpha=0.7 exp_name=anthropic_dpo_jsd_pythia28_hh_beta0.3 gradient_accumulation_steps=4 batch_size=32 eval_batch_size=16 trainer=FSDPTrainer sample_during_eval=false model.fsdp_policy_mp=bfloat16


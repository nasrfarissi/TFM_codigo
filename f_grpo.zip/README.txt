The files used for training and evaluation are:

- grpo.py
- eval.py
- trl/trainer/f_grpo_trainer.py
- trl/trainer/grpo_config.py

Example execution for training (SLURM batch script):

#!/bin/bash

#SBATCH --job-name=trl_grpo          # Job name
#SBATCH --partition=gpu              # Partition/queue name
#SBATCH --gres=gpu:2                 # Number of GPUs
#SBATCH --mem=50G                    # Memory
#SBATCH -w worker-node               # (Optional) Specific node

# Load conda
export PATH="/opt/anaconda/anaconda3/bin:$PATH"
eval "$(conda shell.bash hook)"
conda activate /path/to/conda/env

# Environment variables
export WANDB_API_KEY=your_wandb_api_key_here
export TFHUB_CACHE_DIR=.
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

# Run training
cd /path/to/project/trl_grpo
python grpo.py

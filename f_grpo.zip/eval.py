import os
import re
import json
import argparse
from typing import List, Dict, Any

import torch
from datasets import load_dataset, Dataset
from transformers import AutoTokenizer, AutoModelForCausalLM


SYSTEM_PROMPT = """
Respond in the following format:

<reasoning>
...
</reasoning>
<answer>
...
</answer>
"""

XML_COT_FORMAT = """\
<reasoning>
{reasoning}
</reasoning>
<answer>
{answer}
</answer>
"""

def extract_xml_answer(text: str) -> str:
    answer = text.split("<answer>")[-1]
    answer = answer.split("</answer>")[0]
    return answer.strip()

def extract_hash_answer(text: str) -> str | None:
    if "####" not in text:
        return None
    return text.split("####")[1].strip().replace(",", "").replace("$", "")

def get_gsm8k_questions(split: str = "train") -> Dataset:
    data = load_dataset("openai/gsm8k", "main")[split]  # type: ignore
    data = data.map(lambda x: {  # type: ignore
        "prompt": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": x["question"]},
        ],
        "answer": extract_hash_answer(x["answer"]),
    })  # type: ignore
    return data  # type: ignore

def correctness_reward_func(prompts, completions, answer, **kwargs) -> List[float]:
    responses = [completion[0]["content"] for completion in completions]
    extracted_responses = [extract_xml_answer(r) for r in responses]
    return [2.0 if r == a else 0.0 for r, a in zip(extracted_responses, answer)]

def int_reward_func(completions, **kwargs) -> List[float]:
    responses = [completion[0]["content"] for completion in completions]
    extracted_responses = [extract_xml_answer(r) for r in responses]
    return [0.5 if r.isdigit() else 0.0 for r in extracted_responses]

def strict_format_reward_func(completions, **kwargs) -> List[float]:
    pattern = r"^<reasoning>\n.*?\n</reasoning>\n<answer>\n.*?\n</answer>\n$"
    responses = [completion[0]["content"] for completion in completions]
    matches = [re.match(pattern, r, flags=re.DOTALL) for r in responses]
    return [0.5 if match else 0.0 for match in matches]

def soft_format_reward_func(completions, **kwargs) -> List[float]:
    pattern = r"<reasoning>.*?</reasoning>\s*<answer>.*?</answer>"
    responses = [completion[0]["content"] for completion in completions]
    matches = [re.match(pattern, r, flags=re.DOTALL) for r in responses]
    return [0.5 if match else 0.0 for match in matches]

def count_xml(text) -> float:
    count = 0.0
    if text.count("<reasoning>\n") == 1:
        count += 0.125
    if text.count("\n</reasoning>\n") == 1:
        count += 0.125
    if text.count("\n<answer>\n") == 1:
        count += 0.125
        count -= len(text.split("\n</answer>\n")[-1]) * 0.001
    if text.count("\n</answer>") == 1:
        count += 0.125
        count -= (len(text.split("\n</answer>")[-1]) - 1) * 0.001
    return count

def xmlcount_reward_func(completions, **kwargs) -> List[float]:
    contents = [completion[0]["content"] for completion in completions]
    return [count_xml(c) for c in contents]

REWARD_FUNCS = [
    ("xmlcount", xmlcount_reward_func),
    ("soft_format", soft_format_reward_func),
    ("strict_format", strict_format_reward_func),
    ("int_answer", int_reward_func),
    ("correctness", correctness_reward_func),
]
def resolve_model_path(path: str) -> str:
    """
    If `path` is a run directory containing trainer_state.json with a
    'best_model_checkpoint', prefer that. Otherwise return `path`.
    If `path` is already a checkpoint dir, it will be returned as is.
    """
    ts_path = os.path.join(path, "trainer_state.json")
    if os.path.exists(ts_path):
        try:
            with open(ts_path, "r") as f:
                state = json.load(f)
            best = state.get("best_model_checkpoint")
            if best and os.path.exists(best):
                return best
        except Exception:
            pass
    return path


# Evaluation
@torch.no_grad()
def evaluate(
    model: AutoModelForCausalLM,
    tokenizer: AutoTokenizer,
    dataset: Dataset,
    batch_size: int = 8,
    max_prompt_length: int = 512,
    max_new_tokens: int = 768,
    max_samples: int | None = None,
):
    model.eval()
    device = next(model.parameters()).device

    if max_samples is not None:
        dataset = dataset.select(range(min(max_samples, len(dataset))))

    n = len(dataset)
    results: Dict[str, List[float]] = {name: [] for name, _ in REWARD_FUNCS}
    all_rows: List[Dict[str, Any]] = []

    def chunks(iterable, size):
        for i in range(0, len(iterable), size):
            yield iterable[i : i + size]

    prompts = dataset["prompt"]
    answers = dataset["answer"]

    for idxs in chunks(list(range(n)), batch_size):
        batch_prompts = [prompts[i] for i in idxs]
        batch_answers = [answers[i] for i in idxs]

        # like training chat-formatted inputs 
        prompt_texts = [
            tokenizer.apply_chat_template(
                p, tokenize=False, add_generation_prompt=True
            )
            for p in batch_prompts
        ]

        toks = tokenizer(
            prompt_texts,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=max_prompt_length,
        )
        input_ids = toks.input_ids.to(device)
        attention_mask = toks.attention_mask.to(device)
        input_lengths = attention_mask.sum(dim=1)

        gen = model.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
        )

        batch_texts = []
        for i in range(gen.shape[0]):
            gen_ids = gen[i, input_lengths[i] :].detach().cpu()
            text = tokenizer.decode(gen_ids, skip_special_tokens=True)
            batch_texts.append(text)

        # completions in the same shape the reward funcs expect
        completions = [[{"role": "assistant", "content": t}] for t in batch_texts]

        # Compute rewards
        for name, fn in REWARD_FUNCS:
            vals = fn(completions=completions, prompts=batch_prompts, answer=batch_answers)
            results[name].extend(vals)


    # Summaries
    means = {name: float(torch.tensor(vals).mean().item()) if len(vals) else 0.0
             for name, vals in results.items()}
    overall = sum(means.values()) / len(means) if len(means) else 0.0

    if save_outputs_path:
        with open(save_outputs_path, "w", encoding="utf-8") as f:
            for row in all_rows:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")

    return {"per_metric": means, "overall_avg": overall, "num_samples": n}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_path", type=str, required=True,
                        help="Checkpoint directory (or run dir with trainer_state.json).")
    parser.add_argument("--split", type=str, default="test", choices=["train", "test", "validation"])
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--max_prompt_length", type=int, default=512)
    parser.add_argument("--max_new_tokens", type=int, default=256)
    parser.add_argument("--bf16", action="store_true", help="Load model in bfloat16.")
    parser.add_argument("--max_samples", type=int, default=None)
    args = parser.parse_args()

    ckpt = resolve_model_path(args.model_path)

    # Load model & tokenizer (same as training defaults)
    dtype = torch.bfloat16 if args.bf16 else torch.float16
    tokenizer = AutoTokenizer.from_pretrained(ckpt)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(ckpt, torch_dtype=dtype).to("cuda")

    # Data
    dataset = get_gsm8k_questions(split=args.split)

    # Eval
    out = evaluate(
        model=model,
        tokenizer=tokenizer,
        dataset=dataset,
        batch_size=args.batch_size,
        max_prompt_length=args.max_prompt_length,
        max_new_tokens=args.max_new_tokens,
        max_samples=args.max_samples
    )

    print("=== Evaluation Summary ===")
    print(f"Samples: {out['num_samples']}")
    for k, v in out["per_metric"].items():
        print(f"{k:>14}: {v:.6f}")
    print(f"{'overall_avg':>14}: {out['overall_avg']:.6f}")

if __name__ == "__main__":
    main()
